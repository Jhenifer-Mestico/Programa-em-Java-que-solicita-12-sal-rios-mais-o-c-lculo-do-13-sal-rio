package pessoa01;

public class Resultado {
    
    public static void main(String[] args) {
        
        Trabalhador objTrabalhador = new Trabalhador();
        objTrabalhador.setNome("Jhenifer Mestiço");
        objTrabalhador.setEmail("jhenifer04@gmail.com");
        objTrabalhador.setCpf("345.454.789.-89");
        objTrabalhador.setIdade(22);
      
        System.out.println("O 13°(décimo terceiro salário)será:\n " + "R$ " + objTrabalhador.calculo13Salario() + "(Reias)");
    }
}