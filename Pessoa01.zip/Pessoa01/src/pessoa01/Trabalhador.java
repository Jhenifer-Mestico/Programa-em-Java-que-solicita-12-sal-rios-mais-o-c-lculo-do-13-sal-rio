package pessoa01;

import javax.swing.JOptionPane;

public class Trabalhador extends Pessoa01{
    
    private float salario;
    private int numRegistro;

    public Trabalhador() {
    }

    public Trabalhador(float salario, int numRegistro) {
        this.salario = salario;
        this.numRegistro = numRegistro;
    }

    public float getSalario() {
        return salario;
    }

    public int getNumRegistro() {
        return numRegistro;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public void setNumRegistro(int numRegistro) {
        this.numRegistro = numRegistro;
    }
    
    public float calculo13Salario(){ 
        
        for(int i = 0; i < 12; i++){
            
            salario += Float.parseFloat(JOptionPane.showInputDialog(null,"Digite os 12° salários:", 
                    "Salário do(a) trabalhador(a):", JOptionPane.PLAIN_MESSAGE));
        } 
        
         return(salario * 12 ) / 12;
    }
}